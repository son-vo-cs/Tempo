﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PauseAudio : MonoBehaviour
{
    public KeyCode key;
    public AudioSource source;
    bool active = false;
    // Start is called before the first frame update
    void Start()
    {
        active = false;
        source = GetComponent<AudioSource>();
        source.Play();
    }

    // Update is called once per frame
    void Update()
    {
        
        if (Input.GetKeyDown(key))
        {
            if (active == false)
            {
                active = true;
                source.Pause();
            }
            else
            {
                active = false;
                source.Play();
                
            }
        }
    }
}
